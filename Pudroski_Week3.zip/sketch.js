function setup() {
  createCanvas(650, 400);

  let a = 50;
  let b = 120;
  let c = 180;
  
  

}

function draw() {
  background(200);
  
  colorMode(RGB, 255, 255, 255, 1);
  fill(250)
	
   stroke(153);
  strokeWeight(4);
  strokeCap(SQUARE);

  let a = 50;
  let b = 120;
  let c = 180;

  stroke(153,92,74);
  strokeWeight(4);
  line(a, b, a + c, b);

 stroke(100);
  line(0, height / 2, width, height / 2);
  
  let x1 = 0;
  let y1 = 90;
  let x2 = mouseX;
  let y2 = mouseY;

  line(x1, y1, x2, y2);
  ellipse(x1, y1, 7, 7);
  ellipse(x2, y2, 7, 7);

  // d is the length of the line
  // the distance from point 1 to point 2.
  let d = dist(x1, y1, x2, y2);

  // Let's write d along the line we are drawing!
  push();
  translate((x1 + x2) / 2, (y1 + y2) / 2);
  rotate(atan2(y2 - y1, x2 - x1));
  text(nfc(d, 1), 0, -5);
  pop();
  a = a + c;
  b = height - b;

    stroke(153,0,74);
  strokeWeight(8);
  line(a, b, a + c, b);
  line(a, b + 10, a + c, b + 10);


  a = a + c;
  b = height - b;

    stroke(10,92,74);
  strokeWeight(2);
  line(a, b, a + c, b);
  line(a, b + 30, a + c, b - 10);
  line(a, b - 20, a + c, b + 60);



// initial frameRate value
	let fr = 15;
	frameRate(fr);





// show output of variable fr value, used for frameRate in console

	print(fr);

// set variables to updated values based on current and previous mouse position
  
	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;
  
// set variable to distance between current and previous mouse position


	colorMode(RGB, 255, 255, 255, 1);

// update stroke value to distance between mouse positions


// set a color and alpha vaue for the stroke
	stroke(200, 50, 75, 0.75);

// create a line with the stroke value based on the current and previous mouse positions
	line(mx, my, px, py);
}