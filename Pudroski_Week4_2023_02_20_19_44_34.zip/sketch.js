xyz = 30;
function setup() {
  createCanvas(400, 400);

}

function draw() {
  background(200);
  
 strokeWeight(10);

  
function mouseClicked() {
  	if (xyz == 30) {
		strokeWeight(5);
	}
}

  
  
  if (keyIsPressed) {
  	if (key == 'h') {
  		line(30, 60, 90, 60);
         background(255);
    ellipse(200, 150, 55, 55);
    line(200, 180, 200, 300);
  	} 
    else if ( key == 'n') {
  		line (30, 20, 90, 100);
      line(30, 60, 90, 60);
         background(1);
    ellipse(200, 150, 55, 55);
    line(200, 180, 200, 300);
  	}
  }
  line(200, 180, 200, 300);
  if (keyIsPressed) {

   }
    for (var i = 20; i < 300; i += 60) {
  	line(i, 40, i + 60, 80);
  }
  
  
}