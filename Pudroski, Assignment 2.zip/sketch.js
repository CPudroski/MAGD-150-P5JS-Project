function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(200);
  
  colorMode(RGB, 255, 255, 255, 1);
  fill(250)
	strokeWeight (0);
  ellipse(255, 255, 400, 400);
  
  fill(245)
	strokeWeight (0);
  ellipse(25, 25, 400, 400);
  
  fill(239)
	strokeWeight (0);
  ellipse(25, 300, 400, 400);
  
  fill(220)
	strokeWeight (0);
  ellipse(450, 300, 400, 400);
  
  fill(235)
	strokeWeight (0);
  ellipse(500, 25, 400, 400);
  
  fill(220)
	strokeWeight (0);
  ellipse(10, 150, 250, 250);
  
  fill(255)
	strokeWeight (0);
  ellipse(600, 300, 250, 250);
  
    stroke (190, 22, 15, 1);
	strokeWeight (5);
  fill(230,250,10,1);
  triangle(125, 155, 175, 155, 150, 235);
  triangle(120, 150, 180, 150, 150, 250);
  noFill();
stroke(255, 102, 0);
bezier(150, 255, 175, 290, 120, 340, 230, 360);
  
    stroke (100, 220, 150, 1);
  fill(0,20,100,1);
  quad(300, 290, 247, 260, 350, 190, 410, 230);
    noFill();
stroke(255, 102, 0);
bezier(300, 295, 175, 290, 120, 340, 230, 360);

  translate(50, 50);
stroke(255, 120, 200);
  fill(250,15,150,1);
beginShape();
// Exterior part of shape, clockwise winding
vertex(400, -40);
vertex(500, -40);
vertex(500, 40);
vertex(400, 40);
// Interior part of shape, counter-clockwise winding
beginContour();
vertex(425, -20);
vertex(425, 20);
vertex(475, 20);
vertex(475, -20);
endContour();
endShape(CLOSE);
    noFill();
stroke(255, 102, 0);
bezier(400, 40, 90, 2, 170, 100, 175, 150);
  
  
}